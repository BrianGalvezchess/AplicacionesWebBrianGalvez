package com.example.tienda.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

public record ProductRequest(
    @NotBlank(message = "El nombre no puede estar vacío")
    String name,

    @Positive(message = "El precio debe ser mayor a cero")
    Double price,

    @PositiveOrZero(message = "El stock debe ser mayor o igual a cero")
    int stock
) {

}